const express = require('express');
const router = express.Router();
const { applyDailyInterest } = require('../services/interestService');

/**
 * POST /api/interest/apply
 * Trigger daily compound interest calculation for all active members.
 * Requires header: x-api-key: <your-secret-key>
 */
router.post('/apply', async (req, res) => {
  const apiKey = req.headers['x-api-key'];
  if (!apiKey || apiKey !== process.env.INTEREST_API_KEY) {
    return res.status(401).json({ error: 'Unauthorized: missing or invalid API key' });
  }

  try {
    const result = await applyDailyInterest();
    res.status(200).json({
      success: true,
      message: `Processed ${result.processed} members, total interest: ${result.totalInterest.toFixed(2)}`,
      data: result
    });
  } catch (error) {
    console.error('❌ Error applying interest:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

module.exports = router;