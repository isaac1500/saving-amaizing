const express = require('express');
const router = express.Router();
const { getMemberSuggestions } = require('../controllers/suggestController');

// GET /api/suggestions/members?q=searchTerm
router.get('/members', getMemberSuggestions);

module.exports = router;