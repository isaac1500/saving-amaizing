const express = require('express');
const router = express.Router();
const { 
  validateTransaction, 
  validateDateRange,
  sanitizeRequestBody 
} = require('../middleware/validation');
const { 
  authenticateToken, 
  requireAdmin 
} = require('../middleware/auth');
const { 
  createTransaction, 
  getTransactions, 
  getMemberTransactions,
  getMemberBalance,
  updateTransaction,
  deleteTransaction
} = require('../controllers/transactionController');

// Apply validation and sanitization to all routes
router.use(sanitizeRequestBody);

// POST /api/transactions - Create a new transaction (Admin only)
router.post('/', authenticateToken, requireAdmin, validateTransaction, createTransaction);

// GET /api/transactions - Get all transactions with filtering
router.get('/', authenticateToken, validateDateRange, getTransactions);

// GET /api/transactions/member/:memberId - Get transactions for specific member
router.get('/member/:memberId', authenticateToken, getMemberTransactions);

// GET /api/transactions/balance/:memberId - Get member balance
router.get('/balance/:memberId', authenticateToken, getMemberBalance);

// PUT /api/transactions/:id - Update a transaction (Admin only)
router.put('/:id', authenticateToken, requireAdmin, updateTransaction);

// DELETE /api/transactions/:id - Delete a transaction (Admin only)
router.delete('/:id', authenticateToken, requireAdmin, deleteTransaction);

module.exports = router;