const admin = require('./firebaseService');

// Daily rate: 11.5% annual => 11.5 / 365 / 100
const DAILY_RATE = 0.115 / 365;

/**
 * Helper: calculate the net impact of a transaction on balance.
 * Savings and Interest add; Withdrawals subtract.
 */
function calculateTransactionImpact(tx) {
  let impact = 0;
  if (tx.type === 'Saving') {
    impact += (tx.weeklySaving || 0) + (tx.munomukabi || 0) + (tx.otherSaving || 0);
  } else if (tx.type === 'Withdrawal') {
    impact -= (tx.withdrawal || 0);
  } else if (tx.type === 'Interest') {
    impact += (tx.otherSaving || 0);
  }
  return impact;
}

/**
 * Apply daily compound interest to all active members.
 * @returns {Promise<{ processed: number, totalInterest: number }>}
 */
async function applyDailyInterest() {
  const db = admin.firestore();
  const membersSnapshot = await db.collection('members')
    .where('isActive', '==', true)
    .get();

  let processed = 0;
  let totalInterest = 0;

  for (const memberDoc of membersSnapshot.docs) {
    const memberId = memberDoc.id;
    const memberData = memberDoc.data();

    // Determine the start date for interest calculation
    const lastInterestDate = memberData.lastInterestDate
      ? new Date(memberData.lastInterestDate)
      : new Date(memberData.dateJoined);

    // Yesterday's date (the last day we want to apply interest for)
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    yesterday.setHours(0, 0, 0, 0);

    // If we've already applied interest up to yesterday, skip
    if (lastInterestDate >= yesterday) {
      continue;
    }

    // Fetch all transactions for this member
    // ORDER BY TEMPORARILY REMOVED TO BYPASS INDEX REQUIREMENT
    const txSnapshot = await db.collection('transactions')
      .where('memberId', '==', memberId)
      // .orderBy('date', 'asc')  // <-- COMMENTED OUT - RE-ENABLE AFTER INDEX IS CREATED
      .get();

    // Build a map of transactions by date (YYYY-MM-DD)
    const txMap = new Map();
    txSnapshot.docs.forEach(doc => {
      const tx = doc.data();
      const dateKey = tx.date; // assumes format 'YYYY-MM-DD'
      if (!txMap.has(dateKey)) {
        txMap.set(dateKey, []);
      }
      txMap.get(dateKey).push(tx);
    });

    // Compute balance at the last interest date
    let balance = 0;
    const startDateStr = lastInterestDate.toISOString().split('T')[0];
    txSnapshot.docs.forEach(doc => {
      const tx = doc.data();
      if (tx.date <= startDateStr) {
        balance += calculateTransactionImpact(tx);
      }
    });

    // Prepare to accumulate interest for the period
    let totalMemberInterest = 0;
    let currentDate = new Date(lastInterestDate);
    currentDate.setDate(currentDate.getDate() + 1); // start the day after last interest

    // Loop through each day from start+1 to yesterday
    while (currentDate <= yesterday) {
      const dateKey = currentDate.toISOString().split('T')[0];

      // Apply any transactions that occurred on this day (before interest)
      if (txMap.has(dateKey)) {
        const dayTxs = txMap.get(dateKey);
        for (const tx of dayTxs) {
          // Only apply transactions that are after the start date
          balance += calculateTransactionImpact(tx);
        }
      }

      // Compute interest for this day based on the current balance
      if (balance > 0) {
        const interest = balance * DAILY_RATE;
        totalMemberInterest += interest;
        balance += interest; // compound: add interest to balance
      }

      // Move to next day
      currentDate.setDate(currentDate.getDate() + 1);
    }

    // If any interest was accrued, create a transaction and update member
    if (totalMemberInterest > 0) {
      const txData = {
        memberId: memberId,
        memberName: memberData.fullName || memberData.username || 'Unknown',
        date: yesterday.toISOString().split('T')[0],
        type: 'Interest',
        weeklySaving: 0,
        munomukabi: 0,
        otherSaving: totalMemberInterest, // store interest amount here
        withdrawal: 0,
        enteredBy: 'system',
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      };

      await db.collection('transactions').add(txData);
      console.log(`✅ Interest for ${memberData.fullName || memberId}: ${totalMemberInterest.toFixed(2)}`);
      processed++;
      totalInterest += totalMemberInterest;
    }

    // Update lastInterestDate to yesterday (even if no interest was added)
    await db.collection('members').doc(memberId).update({
      lastInterestDate: yesterday.toISOString().split('T')[0]
    });
  }

  return { processed, totalInterest };
}

module.exports = { applyDailyInterest };