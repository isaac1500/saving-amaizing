const admin = require('../services/firebaseService');

// Simple in-memory cache
const cache = new Map();
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

const searchMembers = async (searchTerm) => {
  try {
    console.log('🔍 Backend: Searching for:', searchTerm);
    
    const membersRef = admin.firestore().collection('members');
    const snapshot = await membersRef
      .where('isActive', '==', true)
      .get();
    
    console.log(`📊 Backend: Found ${snapshot.size} total members in database`);
    
    if (snapshot.empty) {
      console.log('❌ Backend: No members found in database');
      return [];
    }
    
    const allMembers = [];
    snapshot.forEach(doc => {
      const member = { id: doc.id, ...doc.data() };
      allMembers.push(member);
      console.log(`👤 Backend: Member - ${member.fullName} (${member.username})`);
    });
    
    // Simple fuzzy search implementation
    const results = allMembers.filter(member => {
      const searchFields = [
        member.fullName || '',
        member.username || '',
        member.email || '',
        member.residence || ''
      ].map(field => field.toLowerCase());
      
      const found = searchFields.some(field => 
        field.includes(searchTerm.toLowerCase())
      );
      
      if (found) {
        console.log(`✅ Backend: Match found - ${member.fullName}`);
      }
      
      return found;
    });
    
    console.log(`🎯 Backend: Found ${results.length} matches for "${searchTerm}"`);
    
    // Limit to 10 results and rank by relevance
    const finalResults = results
      .sort((a, b) => {
        // Simple ranking: exact matches first
        const aName = a.fullName ? a.fullName.toLowerCase() : '';
        const bName = b.fullName ? b.fullName.toLowerCase() : '';
        
        const aStartsWith = aName.startsWith(searchTerm.toLowerCase());
        const bStartsWith = bName.startsWith(searchTerm.toLowerCase());
        
        if (aStartsWith && !bStartsWith) return -1;
        if (!aStartsWith && bStartsWith) return 1;
        
        return 0;
      })
      .slice(0, 10)
      .map(member => ({
        id: member.id,
        fullName: member.fullName,
        username: member.username,
        email: member.email,
        residence: member.residence
      }));

    console.log('📤 Backend: Sending results:', finalResults);
    return finalResults;
  } catch (error) {
    console.error('❌ Backend: Error searching members:', error);
    throw error;
  }
};

const getMemberSuggestions = async (req, res) => {
  try {
    const { q } = req.query;
    
    console.log('🌐 Backend: API called with query:', q);
    
    if (!q || q.length < 2) {
      console.log('ℹ️ Backend: Query too short, returning empty array');
      return res.status(200).json([]);
    }
    
    const searchTerm = q.toLowerCase().trim();
    const cacheKey = `suggestions:${searchTerm}`;
    
    // Check cache first
    const cached = cache.get(cacheKey);
    if (cached && (Date.now() - cached.timestamp) < CACHE_DURATION) {
      console.log('💾 Backend: Returning cached results');
      return res.status(200).json(cached.data);
    }
    
    // Search in Firebase
    const suggestions = await searchMembers(searchTerm);
    
    // Cache the results
    cache.set(cacheKey, {
      data: suggestions,
      timestamp: Date.now()
    });
    
    console.log(`🚀 Backend: Sending ${suggestions.length} suggestions`);
    res.status(200).json(suggestions);
  } catch (error) {
    console.error('💥 Backend: Error in getMemberSuggestions:', error);
    res.status(500).json({ 
      error: 'Internal server error',
      message: error.message 
    });
  }
};

module.exports = {
  getMemberSuggestions
};