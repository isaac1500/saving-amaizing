const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const admin = require('./src/services/firebaseService');

// Load environment variables
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3002;

// Simple CORS for development
app.use(cors({
  origin: ['http://localhost:3000', 'http://localhost:3001', 'http://localhost:3002'],
  credentials: true
}));

// Body parsing
app.use(express.json());

// Request logging middleware
app.use((req, res, next) => {
  console.log(`📡 ${req.method} ${req.originalUrl}`);
  next();
});

// ============================================================
// ROUTES
// ============================================================

// Suggestions API (existing)
app.use('/api/suggestions', require('./src/routes/suggestions'));

// Interest API (new)
app.use('/api/interest', require('./src/routes/interest'));

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.status(200).json({
    status: 'OK',
    message: 'Server is running',
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'development'
  });
});

// Test endpoint
app.get('/api/test', (req, res) => {
  res.status(200).json({
    message: 'Backend API is working!',
    timestamp: new Date().toISOString()
  });
});

// Reports endpoints (existing)
app.get('/api/reports/group-summary', async (req, res) => {
  try {
    console.log('📊 Generating group summary...');
    
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('Request timeout')), 10000);
    });

    const generateSummary = async () => {
      const db = admin.firestore();
      
      const [membersSnapshot, transactionsSnapshot] = await Promise.all([
        db.collection('members')
          .where('isActive', '==', true)
          .get(),
        db.collection('transactions').get()
      ]);
      
      let totalSavings = 0;
      let totalWithdrawals = 0;
      
      transactionsSnapshot.forEach(doc => {
        const transaction = doc.data();
        if (transaction.type === 'Saving') {
          totalSavings += (parseFloat(transaction.weeklySaving) || 0) +
                         (parseFloat(transaction.munomukabi) || 0) +
                         (parseFloat(transaction.otherSaving) || 0);
        } else if (transaction.type === 'Withdrawal') {
          totalWithdrawals += parseFloat(transaction.withdrawal) || 0;
        }
      });
      
      const summary = {
        totalMembers: membersSnapshot.size,
        totalSavings: totalSavings,
        totalWithdrawals: totalWithdrawals,
        netBalance: totalSavings - totalWithdrawals,
        recentActivity: [],
        timestamp: new Date().toISOString()
      };
      
      console.log('✅ Group summary generated:', summary);
      return summary;
    };

    const summary = await Promise.race([generateSummary(), timeoutPromise]);
    res.status(200).json(summary);

  } catch (error) {
    console.error('❌ Error generating group summary:', error.message);
    res.status(200).json({
      totalMembers: 0,
      totalSavings: 0,
      totalWithdrawals: 0,
      netBalance: 0,
      recentActivity: [],
      timestamp: new Date().toISOString(),
      note: 'Using fallback data due to processing delay'
    });
  }
});

// Members reports (existing)
app.get('/api/reports/members', async (req, res) => {
  try {
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('Request timeout')), 8000);
    });

    const fetchMembers = async () => {
      const db = admin.firestore();
      const membersSnapshot = await db.collection('members')
        .where('isActive', '==', true)
        .get();
      
      const members = [];
      membersSnapshot.forEach(doc => {
        members.push({
          id: doc.id,
          ...doc.data()
        });
      });
      
      return members;
    };

    const members = await Promise.race([fetchMembers(), timeoutPromise]);
    res.status(200).json(members);

  } catch (error) {
    console.error('❌ Error fetching member reports:', error.message);
    res.status(200).json([]);
  }
});

// Quick summary (existing)
app.get('/api/reports/quick-summary', async (req, res) => {
  try {
    const db = admin.firestore();
    const membersSnapshot = await db.collection('members')
      .where('isActive', '==', true)
      .get();
    
    res.status(200).json({
      totalMembers: membersSnapshot.size,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ Error in quick summary:', error);
    res.status(200).json({
      totalMembers: 0,
      timestamp: new Date().toISOString()
    });
  }
});

// Root endpoint
app.get('/', (req, res) => {
  res.status(200).json({
    message: 'Savings Group Management API',
    version: '1.0.0',
    status: 'Running',
    endpoints: {
      health: '/api/health',
      test: '/api/test',
      suggestions: '/api/suggestions/members',
      reports: '/api/reports/group-summary',
      quickReports: '/api/reports/quick-summary',
      interest: '/api/interest/apply (POST, requires API key)'
    },
    timestamp: new Date().toISOString()
  });
});

// 404 handler - FIXED
app.use((req, res) => {
  res.status(404).json({
    error: 'Endpoint not found',
    path: req.originalUrl,
    method: req.method,
    timestamp: new Date().toISOString(),
    availableEndpoints: [
      'GET /',
      'GET /api/health',
      'GET /api/test',
      'GET /api/suggestions/members',
      'GET /api/reports/group-summary',
      'GET /api/reports/members',
      'GET /api/reports/quick-summary',
      'POST /api/interest/apply'
    ]
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('❌ Unhandled error:', err);
  res.status(500).json({
    error: 'Internal server error',
    message: process.env.NODE_ENV === 'development' ? err.message : 'Something went wrong',
    timestamp: new Date().toISOString()
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`🌍 Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`🏥 Health check: http://localhost:${PORT}/api/health`);
  console.log(`🔍 Test endpoint: http://localhost:${PORT}/api/test`);
  console.log(`🔍 Suggestions API: http://localhost:${PORT}/api/suggestions/members`);
  console.log(`📊 Reports API: http://localhost:${PORT}/api/reports/group-summary`);
  console.log(`⚡ Quick Reports: http://localhost:${PORT}/api/reports/quick-summary`);
  console.log(`💰 Interest API: POST http://localhost:${PORT}/api/interest/apply (requires API key)`);
});