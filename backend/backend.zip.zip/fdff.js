{
  "type": "service_account",
  "project_id": "savings-group-bcec8",
  "private_key_id": "841aadcf9b1691f457b3c3d6a1cb61c06c264f61",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDi+r8zNwEtDBwg\nzxT8ueZ5wImgKeRfBuloGE9sTb7pPpWF/gbKSZGpfHk7AEXE3v1PGXt/pC82rGE6\njIS8d9aJk8cACgp18OuUUZw5wbCS+1VNrcT0j/oV0sRt78cYtliUBftEll8AtVBl\nIJ8oLd2rDyAdGbqMUr+8sp1PWFgLPsgL4tUFYI2jphQ8M4PvrS+MWljtFXKlxfp4\nvu2bO9PJ6GvY708ZVtnWNx9sAEKs4KT0M0/xGamE9FDMu76//lZ9PN3ennxQp++m\nIgLmRXROLfzuHF92LGBxjV/SK34aQ2CW9KPmZOJd5qQpNY0avPgTlEVgjqsisHrp\npncnvVhhAgMBAAECggEALPxfesoTDJeS15nTYgeCO21CmaDT51WaWww+aYu7I8VI\no0bml58fJIVMDbqPGWbMs6msRW8IAIEHwC/reuMRfTDxxvs2eYunVT0bhoLx+R+h\nF4UyPPpwKXUdg2B7iFVTlvrcgwp+h8hnx7NAeBknDukvhzT7OSaJY9/Ot9QdlxSZ\nx+zE1Ib42oKIo3SqWR+Izcsin0P1XolRaR6eCMPEAkUBCxZF6vJMJZY8/MpQbjBO\n3fBw4s2f2PoC/jwL3GyqkFyou+I2eVJapeEMDqvStbPqprNk+uIvlXv4HXOlmFPP\niIooXHcSoU4OwiB7qGPA1lDWi1AJBpEys4k/l7n7cQKBgQD0UbhwPWIvNiYBJTu1\nFsApuNMcq4fGavoqayMsjjUjaHSHRmO+H5FnNIiGINnwcXcoQUgPb8ldBETudp3C\nsqjMllbv1jjGiYI3JYeKP6Yep/VOD7/BtOQaQoGsvaiGC6uv8CI9YIkhAEhNoL9O\nTkHR05zjXiBkF3XmmP0+78ts1QKBgQDt1M0itfvHi8QCLftrKdpwSapFDt7DQn0i\nry6fV0ski3PJxDShQD8R8QriePKKlwE+xLXI8hQTN234eX51St/5jYN2OxwM8LKA\nqYZ3ygqznIMi+1VFZOctsSdMzUm7sFsbfLW50gt4CnPnQKM5t2Jj9RQfDhtV33Nl\nIxM7UDcTXQKBgHIAP8N/oPTOm2UlbnrNJtVQ/JEAKNaYzCpG257KrFjdQKJuYdQw\n/rPde2a6pXbgOu15qJorWxYgC9oJVwumOcVc0SwQFWXue+gnhtsnX+gmDvxhtOQ5\n98WZCtEDnkMN5wqtTgy9or7XVuWCAEIVmfjCeQ5OuWZ62/TBpklbstwRAoGAdMp2\nfiAt5zz8YTGhcGuaKGAUbFs0C2EAQGMUmwzsCqMslh1y1ujM0Au1k6dfO62R3/gL\naQVv1Ev5Bfbrob/GIy9aKlo2mSguED6vmO2vuaoXP7t6kVxOpkKDkRSSq8ebxfDE\n8N5z4VwItLwqK7Khb4KvgdyUkePsL/M8g3kNwsUCgYEA3UxGD/79qhf+GQrtKtpw\nUyFV0dGPpE88B1WoGtB6ChxNR2TZFY4sUFs/OjFsOnVaXr91tvrpCJFRfkQLv8oi\nKoL5C8v9pHD5K4xUH5IDw5194vLKm+GMTobvWoofU58l0QtgpeRSJjWJglIINuRZ\nY1MlBbykxD7EUNcg2LIBXy8=\n-----END PRIVATE KEY-----\n",
  "client_email": "firebase-adminsdk-fbsvc@savings-group-bcec8.iam.gserviceaccount.com",
  "client_id": "106165683551567252508",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-fbsvc%40savings-group-bcec8.iam.gserviceaccount.com",
  "universe_domain": "googleapis.com"
}
